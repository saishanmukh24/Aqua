import { Fish } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-border px-6 py-16">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 md:flex-row">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-glow to-ocean shadow-glow">
            <Fish className="h-5 w-5 text-abyss" strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-bold">
            Abyssal<span className="gradient-text">Co</span>
          </span>
        </div>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} AbyssalCo · Crafted in the deep.
        </p>
        <div className="flex gap-6 text-sm text-muted-foreground">
          <a href="#" className="hover:text-glow">Instagram</a>
          <a href="#" className="hover:text-glow">YouTube</a>
          <a href="#" className="hover:text-glow">Contact</a>
        </div>
      </div>
    </footer>
  );
}
